import { jsonb, text, timestamp, pgTable } from "drizzle-orm/pg-core";

export const learningState = pgTable("learning_state", {
  id: text("id").primaryKey(),
  data: jsonb("data").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});