# AI Learning & Study Assistant

An agentic learning workspace that turns course materials into grounded answers, personalized study plans, generated quizzes, learner memory, progress signals, and an internship-ready project report.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/ai-learning-assistant/src/` — responsive React app routes and visual system
- `artifacts/api-server/src/routes/learning.ts` — learning workflows, agent orchestration, RAG retrieval, memory, quiz scoring, and report payload
- `artifacts/api-server/src/routes/storage.ts` — App Storage presigned upload and serving endpoints
- `lib/api-spec/openapi.yaml` — source of truth for the API contract
- `lib/db/src/schema/learning.ts` — persisted demo learner state

## Architecture decisions

- The API contract is OpenAPI-first and generates the typed React Query client used by the frontend.
- The first-build learner state is persisted as one JSON document in PostgreSQL so the demonstration can seed a coherent workspace without over-modeling every learning entity.
- Retrieval is intentionally transparent keyword-ranked chunking for the internship demo; the UI exposes citations and agent steps so the Agent + RAG loop is inspectable.
- App Storage uploads use Replit's sidecar signed-object-url flow; uploaded bytes are stored outside PostgreSQL while searchable text and metadata remain in the learning state.

## Product

- Dashboard with daily focus, plan progress, learner stats, recent activity, and next action
- Course material upload/indexing and material management
- Grounded Q&A with citations, confidence, and visible agent steps
- Personalized study plan generation and task completion
- Quiz generation, submission, scoring, and feedback
- Progress analytics, study streaks, milestones, and learner memory
- Four-part internship report with live evidence from the workspace

## User preferences

- The user asked for a complete functional final-project demonstration, not a static prototype.

## Gotchas

- After changing `lib/api-spec/openapi.yaml`, rerun `pnpm --filter @workspace/api-spec run codegen`.
- App Storage object paths are relative to `PRIVATE_OBJECT_DIR`; sign URLs through the Replit object-storage sidecar rather than the default Google client credentials.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
