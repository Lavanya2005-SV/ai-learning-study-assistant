import { Router, type IRouter } from "express";
import healthRouter from "./health";
import learningRouter from "./learning";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(learningRouter);
router.use(storageRouter);

export default router;
