import { Router, type IRouter } from "express";
import { randomUUID } from "node:crypto";
import { RequestUploadUrlBody } from "@workspace/api-zod";

const router: IRouter = Router();
const sidecarEndpoint = "http://127.0.0.1:1106";

function privatePrefix() {
  const prefix = process.env.PRIVATE_OBJECT_DIR;
  if (!prefix) throw new Error("Object storage is not configured");
  return prefix.replace(/^\/+|\/+$/g, "");
}

function parseObjectPath(path: string) {
  const parts = path.replace(/^\/+/, "").split("/");
  if (parts.length < 2) throw new Error("Invalid object storage path");
  return { bucketName: parts[0], objectName: parts.slice(1).join("/") };
}

async function signObjectUrl(objectPath: string, method: "GET" | "PUT") {
  const { bucketName, objectName } = parseObjectPath(objectPath);
  const response = await fetch(`${sidecarEndpoint}/object-storage/signed-object-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      bucket_name: bucketName,
      object_name: objectName,
      method,
      expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`Object storage signing failed with ${response.status}`);
  const payload = await response.json() as { signed_url: string };
  return payload.signed_url;
}

router.post("/storage/uploads/request-url", async (req, res) => {
  try {
    const input = RequestUploadUrlBody.parse(req.body);
    const safeName = input.name.replace(/[^a-zA-Z0-9._-]/g, "-").slice(-80);
    const entityPath = `uploads/${randomUUID()}-${safeName}`;
    const uploadURL = await signObjectUrl(`${privatePrefix()}/${entityPath}`, "PUT");
    res.json({ uploadURL, objectPath: `/objects/${entityPath}`, metadata: input });
  } catch (error) {
    req.log.error({ error }, "Failed to create object upload URL");
    res.status(400).json({ error: "Unable to create an upload URL" });
  }
});

router.get("/storage/objects/*splat", async (req, res) => {
  try {
    const rawPath = Array.isArray(req.params.splat) ? req.params.splat.join("/") : req.params.splat;
    const objectURL = await signObjectUrl(`${privatePrefix()}/${rawPath.replace(/^\/+/, "")}`, "GET");
    const objectResponse = await fetch(objectURL);
    if (!objectResponse.ok) return res.status(404).json({ error: "Object not found" });
    res.setHeader("Content-Type", objectResponse.headers.get("content-type") ?? "application/octet-stream");
    res.setHeader("Cache-Control", "private, max-age=3600");
    return res.send(Buffer.from(await objectResponse.arrayBuffer()));
  } catch (error) {
    req.log.error({ error }, "Failed to serve object");
    return res.status(500).json({ error: "Unable to serve object" });
  }
});

export default router;