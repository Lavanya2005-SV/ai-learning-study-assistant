import { Router, type IRouter } from "express";
import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import {
  AskCourseQuestionBody,
  CreateDocumentBody,
  CreateMemoryBody,
  GenerateQuizBody,
  GenerateStudyPlanBody,
  SubmitQuizBody,
  UpdateStudyTaskBody,
} from "@workspace/api-zod";
import { db, learningState } from "@workspace/db";

type Document = {
  id: string;
  name: string;
  type: string;
  size: number;
  status: string;
  uploadedAt: string;
  chunkCount: number;
  objectPath: string | null;
  content: string;
};

type StudyTask = {
  id: string;
  title: string;
  week: number;
  minutes: number;
  type: string;
  completed: boolean;
};

type StudyPlan = {
  id: string;
  title: string;
  goal: string;
  durationWeeks: number;
  weeklyHours: number;
  progress: number;
  createdAt: string;
  tasks: StudyTask[];
};

type QuizQuestion = {
  id: string;
  prompt: string;
  options: string[];
  answer: number;
  explanation: string;
};

type Quiz = {
  id: string;
  title: string;
  difficulty: string;
  createdAt: string;
  questions: QuizQuestion[];
};

type MemoryItem = {
  id: string;
  category: string;
  content: string;
  source: string;
  createdAt: string;
};

type Activity = {
  id: string;
  title: string;
  detail: string;
  time: string;
  type: string;
};

type Store = {
  documents: Document[];
  studyPlans: StudyPlan[];
  quizzes: Quiz[];
  memory: MemoryItem[];
  activities: Activity[];
  progress: {
    studyMinutes: number;
    questionsAnswered: number;
    quizAttempts: number;
    averageScore: number;
    weeklyMinutes: { day: string; minutes: number }[];
    milestones: string[];
  };
};

const now = () => new Date().toISOString();

const seedStore = (): Store => ({
  documents: [
    {
      id: "doc-rag-foundations",
      name: "RAG Foundations — Week 1.md",
      type: "text/markdown",
      size: 4860,
      status: "indexed",
      uploadedAt: "2026-09-07T09:20:00.000Z",
      chunkCount: 6,
      objectPath: null,
      content: `Retrieval-Augmented Generation (RAG) combines a retrieval system with a language model. Instead of asking a model to answer from parameters alone, the system first searches a trusted knowledge base and then provides the most relevant passages as context.\n\nA typical RAG pipeline has five stages: document ingestion, chunking, embedding, retrieval, and grounded generation. Chunking breaks long documents into passages that preserve enough meaning to stand on their own. Embeddings represent the semantic meaning of each passage as a vector. Retrieval compares a question with passage vectors and returns the highest-scoring context.\n\nRAG is useful because it reduces hallucinations, keeps answers tied to current or private material, and makes citations possible. A strong system still needs evaluation: measure retrieval precision, answer faithfulness, and whether the response actually answers the learner's question.\n\nAgentic RAG adds a controller that can decide when to retrieve, which sources to use, whether memory is relevant, and what action to take next. Tools allow the controller to call retrieval, scoring, or scheduling functions rather than doing every task in one prompt.`,
    },
  ],
  studyPlans: [
    {
      id: "plan-agentic-ai",
      title: "Agentic AI Foundations Sprint",
      goal: "Prepare for an Agentic AI internship evaluation",
      durationWeeks: 4,
      weeklyHours: 5,
      progress: 38,
      createdAt: "2026-09-05T07:00:00.000Z",
      tasks: [
        { id: "task-1", title: "Review RAG pipeline stages", week: 1, minutes: 45, type: "learn", completed: true },
        { id: "task-2", title: "Explain embeddings in your own words", week: 1, minutes: 30, type: "practice", completed: true },
        { id: "task-3", title: "Build a retrieval evaluation checklist", week: 1, minutes: 40, type: "build", completed: false },
        { id: "task-4", title: "Study tool calling patterns", week: 2, minutes: 50, type: "learn", completed: false },
        { id: "task-5", title: "Generate and take a retrieval quiz", week: 2, minutes: 35, type: "practice", completed: false },
        { id: "task-6", title: "Write a one-page project reflection", week: 3, minutes: 45, type: "reflect", completed: false },
      ],
    },
  ],
  quizzes: [
    {
      id: "quiz-rag-basics",
      title: "RAG Foundations Check-in",
      difficulty: "Intermediate",
      createdAt: "2026-09-07T12:10:00.000Z",
      questions: [
        {
          id: "q1",
          prompt: "What is the main purpose of retrieval in a RAG pipeline?",
          options: ["To replace the language model", "To provide trusted, relevant context", "To increase document length", "To hide citations"],
          answer: 1,
          explanation: "Retrieval finds relevant passages from a trusted knowledge base so the model can ground its answer.",
        },
        {
          id: "q2",
          prompt: "Which stage turns long source documents into meaningful passages?",
          options: ["Chunking", "Deployment", "Scoring", "Rendering"],
          answer: 0,
          explanation: "Chunking breaks documents into passages that can be retrieved independently.",
        },
        {
          id: "q3",
          prompt: "Which benefit is directly associated with grounded generation?",
          options: ["Less need for source material", "Fewer hallucinations", "No need to evaluate retrieval", "Unlimited context"],
          answer: 1,
          explanation: "Grounded generation keeps responses tied to retrieved sources, which can reduce hallucinations.",
        },
      ],
    },
  ],
  memory: [
    { id: "mem-style", category: "learning style", content: "Prefers short explanations followed by a concrete example.", source: "Onboarding preference", createdAt: "2026-09-05T07:05:00.000Z" },
    { id: "mem-goal", category: "goal", content: "Preparing for an Agentic AI internship evaluation.", source: "Study plan", createdAt: "2026-09-05T07:06:00.000Z" },
    { id: "mem-progress", category: "progress", content: "Strong on RAG fundamentals; needs more practice with evaluation and tool orchestration.", source: "Quiz reflection", createdAt: "2026-09-07T12:25:00.000Z" },
  ],
  activities: [
    { id: "activity-1", title: "Completed a RAG review", detail: "2 tasks checked off in Agentic AI Foundations", time: "Today, 9:40 AM", type: "plan" },
    { id: "activity-2", title: "Scored 83% on RAG Foundations", detail: "Strong retrieval fundamentals", time: "Yesterday, 6:12 PM", type: "quiz" },
    { id: "activity-3", title: "Added a learning preference", detail: "Short explanations with examples", time: "Sep 5, 7:05 AM", type: "memory" },
  ],
  progress: {
    studyMinutes: 185,
    questionsAnswered: 12,
    quizAttempts: 2,
    averageScore: 83,
    weeklyMinutes: [
      { day: "Mon", minutes: 28 },
      { day: "Tue", minutes: 42 },
      { day: "Wed", minutes: 18 },
      { day: "Thu", minutes: 36 },
      { day: "Fri", minutes: 24 },
      { day: "Sat", minutes: 15 },
      { day: "Sun", minutes: 22 },
    ],
    milestones: ["First material indexed", "First grounded answer", "5-day study streak"],
  },
});

async function getStore(): Promise<Store> {
  const rows = await db.select().from(learningState).where(eq(learningState.id, "demo-learner"));
  if (rows[0]) return rows[0].data as Store;
  const initial = seedStore();
  await db.insert(learningState).values({ id: "demo-learner", data: initial });
  return initial;
}

async function saveStore(store: Store) {
  await db
    .update(learningState)
    .set({ data: store, updatedAt: new Date() })
    .where(eq(learningState.id, "demo-learner"));
}

function publicDocument(document: Document) {
  const { content: _content, ...safe } = document;
  return safe;
}

function publicPlan(plan: StudyPlan) {
  return plan;
}

function splitIntoChunks(text: string) {
  return text
    .split(/\n{2,}|(?<=[.!?])\s+(?=[A-Z])/)
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .slice(0, 40);
}

function retrieveContext(store: Store, question: string, ids?: string[]) {
  const terms = question.toLowerCase().split(/\W+/).filter((term) => term.length > 2);
  return store.documents
    .filter((document) => !ids?.length || ids.includes(document.id))
    .flatMap((document) =>
      splitIntoChunks(document.content).map((excerpt) => {
        const lower = excerpt.toLowerCase();
        const score = terms.reduce((total, term) => total + (lower.includes(term) ? 1 : 0), 0);
        return { document: document.name, excerpt, relevance: Math.min(99, 48 + score * 12) };
      }),
    )
    .sort((a, b) => b.relevance - a.relevance)
    .slice(0, 5);
}

type AgentMessage = Record<string, unknown>;

async function chatWithAgent(messages: AgentMessage[], tools: Record<string, (args: Record<string, unknown>) => unknown>) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is not configured");
  const toolDefinitions = Object.keys(tools).map((name) => ({
    type: "function",
    function: {
      name,
      description: name === "retrieve_course_context" ? "Retrieve relevant passages from indexed course materials." : "Read remembered learner preferences and progress.",
      parameters: name === "retrieve_course_context"
        ? { type: "object", properties: { question: { type: "string" }, documentIds: { type: "array", items: { type: "string" } } }, required: ["question"] }
        : { type: "object", properties: {}, additionalProperties: false },
    },
  }));
  let history = [...messages];
  for (let step = 0; step < 3; step += 1) {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL ?? "gpt-4.1-mini", messages: history, tools: toolDefinitions, tool_choice: "auto", temperature: 0.2 }),
    });
    if (!response.ok) throw new Error(`OpenAI request failed with status ${response.status}`);
    const payload = await response.json() as { choices?: [{ message?: AgentMessage }] };
    const message = payload.choices?.[0]?.message;
    if (!message) throw new Error("Agent returned no message");
    const calls = Array.isArray(message.tool_calls) ? message.tool_calls as { id: string; function: { name: string; arguments: string } }[] : [];
    if (!calls.length) return String(message.content ?? "");
    history.push(message);
    for (const call of calls) {
      const args = JSON.parse(call.function.arguments || "{}") as Record<string, unknown>;
      const output = tools[call.function.name]?.(args) ?? { error: "Unknown tool" };
      history.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(output) });
    }
  }
  throw new Error("Agent reached its tool-call limit");
}

function parseJson<T>(raw: string): T {
  const cleaned = raw.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
  return JSON.parse(cleaned) as T;
}

function fallbackAnswer(store: Store, question: string) {
  const citations = retrieveContext(store, question);
  return {
    answer: citations[0]
      ? `${citations[0].excerpt} In practice, this means the assistant should retrieve relevant source passages before asking the language model to explain them.`
      : "I could not find a matching passage in the indexed course materials yet. Upload a relevant note or ask about RAG foundations.",
    citations,
    confidence: citations.length ? "High" : "Low",
    agentSteps: ["Read learner memory", "Retrieved relevant course passages", "Generated a grounded response"],
  };
}

const router: IRouter = Router();

router.get("/dashboard", async (_req, res) => {
  const store = await getStore();
  const plan = store.studyPlans[0];
  const completed = plan?.tasks.filter((task) => task.completed).length ?? 0;
  const total = plan?.tasks.length ?? 0;
  res.json({
    learner: { name: "Aarav", goal: "Agentic AI internship readiness", level: "Intermediate" },
    stats: {
      studyMinutes: store.progress.studyMinutes,
      questionsAnswered: store.progress.questionsAnswered,
      materials: store.documents.length,
      currentStreak: 5,
    },
    planProgress: { completed, total, percentage: total ? Math.round((completed / total) * 100) : 0 },
    recentActivity: store.activities.slice(0, 4),
    nextAction: plan?.tasks.find((task) => !task.completed)
      ? { title: plan.tasks.find((task) => !task.completed)!.title, description: "Continue your active learning plan", type: "plan" }
      : { title: "Ask a grounded question", description: "Use your indexed materials to deepen understanding", type: "ask" },
  });
});

router.get("/documents", async (_req, res) => {
  const store = await getStore();
  res.json(store.documents.map(publicDocument));
});

router.post("/documents", async (req, res) => {
  const input = CreateDocumentBody.parse(req.body);
  const chunks = splitIntoChunks(input.content);
  const store = await getStore();
  const document: Document = {
    id: randomUUID(),
    name: input.name,
    type: input.type,
    size: input.size,
    status: "indexed",
    uploadedAt: now(),
    chunkCount: chunks.length,
    objectPath: input.objectPath ?? null,
    content: input.content,
  };
  store.documents.unshift(document);
  store.activities.unshift({ id: randomUUID(), title: "Indexed new material", detail: `${document.name} is ready for grounded Q&A`, time: "Just now", type: "material" });
  store.progress.milestones = Array.from(new Set([...store.progress.milestones, "Course material indexed"]));
  await saveStore(store);
  res.status(201).json(publicDocument(document));
});

router.delete("/documents/:id", async (req, res) => {
  const store = await getStore();
  store.documents = store.documents.filter((document) => document.id !== req.params.id);
  await saveStore(store);
  res.status(204).send();
});

router.post("/qa", async (req, res) => {
  const input = AskCourseQuestionBody.parse(req.body);
  const store = await getStore();
  let answer: ReturnType<typeof fallbackAnswer>;
  try {
    const raw = await chatWithAgent(
      [
        { role: "system", content: "You are a patient course-material tutor. Use the retrieval and memory tools before answering. Return only valid JSON with keys answer, citations (array of document, excerpt, relevance), confidence, and agentSteps (array of short strings). Never invent facts not supported by the retrieved passages." },
        { role: "user", content: JSON.stringify({ question: input.question, documentIds: input.documentIds ?? [] }) },
      ],
      {
        retrieve_course_context: (args) => retrieveContext(store, String(args.question), args.documentIds as string[] | undefined),
        get_learner_memory: () => store.memory,
      },
    );
    answer = parseJson<ReturnType<typeof fallbackAnswer>>(raw);
  } catch (error) {
    req.log.warn({ error: error instanceof Error ? error.message : String(error) }, "Falling back to deterministic grounded answer");
    answer = fallbackAnswer(store, input.question);
  }
  store.progress.questionsAnswered += 1;
  store.activities.unshift({ id: randomUUID(), title: "Answered a course question", detail: input.question.slice(0, 80), time: "Just now", type: "ask" });
  await saveStore(store);
  res.json(answer);
});

router.get("/study-plans", async (_req, res) => {
  const store = await getStore();
  res.json(store.studyPlans.map(publicPlan));
});

router.post("/study-plans", async (req, res) => {
  const input = GenerateStudyPlanBody.parse(req.body);
  const store = await getStore();
  let generated: { title: string; tasks: StudyTask[] } | null = null;
  try {
    const raw = await chatWithAgent(
      [
        { role: "system", content: "You are a learning-plan agent. Read learner memory, then create a realistic study plan. Return only JSON with title and tasks. Each task must have title, week (number), minutes (number), type, completed (false)." },
        { role: "user", content: JSON.stringify(input) },
      ],
      { get_learner_memory: () => store.memory },
    );
    generated = parseJson<{ title: string; tasks: StudyTask[] }>(raw);
  } catch (error) {
    req.log.warn({ error: error instanceof Error ? error.message : String(error) }, "Falling back to deterministic study plan");
  }
  const tasks = generated?.tasks?.length ? generated.tasks.slice(0, 12).map((task, index) => ({ ...task, id: task.id ?? `task-${randomUUID()}`, week: Number(task.week) || Math.floor(index / 3) + 1, minutes: Number(task.minutes) || 35, completed: false })) : Array.from({ length: Math.min(6, input.durationWeeks * 2) }, (_, index) => ({
    id: `task-${randomUUID()}`,
    title: ["Learn the core concepts", "Make a one-page summary", "Practice with active recall", "Apply the idea to a mini project", "Take a self-check quiz", "Reflect and identify gaps"][index] ?? "Review the next topic",
    week: Math.floor(index / 2) + 1,
    minutes: 35,
    type: index % 2 ? "practice" : "learn",
    completed: false,
  }));
  const plan: StudyPlan = {
    id: randomUUID(),
    title: generated?.title ?? `${input.goal} study plan`,
    goal: input.goal,
    durationWeeks: input.durationWeeks,
    weeklyHours: input.hoursPerWeek,
    progress: 0,
    createdAt: now(),
    tasks,
  };
  store.studyPlans.unshift(plan);
  store.activities.unshift({ id: randomUUID(), title: "Created a personalized study plan", detail: plan.title, time: "Just now", type: "plan" });
  await saveStore(store);
  res.status(201).json(plan);
});

router.patch("/study-plans/:id/tasks/:taskId", async (req, res) => {
  const input = UpdateStudyTaskBody.parse(req.body);
  const store = await getStore();
  const plan = store.studyPlans.find((item) => item.id === req.params.id);
  if (!plan) return res.status(404).json({ error: "Study plan not found" });
  const task = plan.tasks.find((item) => item.id === req.params.taskId);
  if (!task) return res.status(404).json({ error: "Study task not found" });
  task.completed = input.completed;
  plan.progress = Math.round((plan.tasks.filter((item) => item.completed).length / plan.tasks.length) * 100);
  store.progress.studyMinutes += input.completed ? task.minutes : -task.minutes;
  await saveStore(store);
  return res.json(plan);
});

router.get("/quizzes", async (_req, res) => {
  const store = await getStore();
  res.json(store.quizzes);
});

router.post("/quizzes", async (req, res) => {
  const input = GenerateQuizBody.parse(req.body);
  const store = await getStore();
  let quiz: Quiz | null = null;
  try {
    const raw = await chatWithAgent(
      [
        { role: "system", content: "You are a quiz-generation agent. Use the retrieval tool before writing questions. Return only JSON with title and questions. Each question has prompt, options (exactly four strings), answer (zero-based integer), and explanation." },
        { role: "user", content: JSON.stringify(input) },
      ],
      { retrieve_course_context: (args) => retrieveContext(store, String(args.question ?? input.topic ?? input.title), args.documentIds as string[] | undefined), get_learner_memory: () => store.memory },
    );
    const parsed = parseJson<{ title: string; questions: QuizQuestion[] }>(raw);
    if (parsed.questions?.length) quiz = { id: randomUUID(), title: parsed.title ?? input.title, difficulty: input.difficulty, createdAt: now(), questions: parsed.questions.slice(0, input.questionCount).map((question) => ({ ...question, id: question.id ?? randomUUID(), answer: Number(question.answer) || 0 })) };
  } catch (error) {
    req.log.warn({ error: error instanceof Error ? error.message : String(error) }, "Falling back to deterministic quiz");
  }
  if (!quiz) {
    const contexts = retrieveContext(store, input.topic ?? input.title);
    quiz = {
      id: randomUUID(),
      title: input.title,
      difficulty: input.difficulty,
      createdAt: now(),
      questions: Array.from({ length: Math.max(1, Math.min(5, input.questionCount)) }, (_, index) => ({
        id: randomUUID(),
        prompt: index === 0 ? "What is the role of retrieval in a RAG system?" : index === 1 ? "Why does chunking matter for course materials?" : "Which outcome is a benefit of grounded generation?",
        options: index === 0 ? ["Provide trusted context", "Replace memory", "Remove documents", "Hide sources"] : index === 1 ? ["It creates retrievable passages", "It deletes context", "It prevents evaluation", "It changes the model weights"] : ["Fewer hallucinations", "No need for sources", "Unlimited context", "No need for testing"],
        answer: 0,
        explanation: contexts[0]?.excerpt ?? "This answer is grounded in the indexed course material.",
      })),
    };
  }
  store.quizzes.unshift(quiz);
  store.activities.unshift({ id: randomUUID(), title: "Generated a new quiz", detail: quiz.title, time: "Just now", type: "quiz" });
  await saveStore(store);
  res.status(201).json(quiz);
});

router.post("/quizzes/:id/submit", async (req, res) => {
  const input = SubmitQuizBody.parse(req.body);
  const store = await getStore();
  const quiz = store.quizzes.find((item) => item.id === req.params.id);
  if (!quiz) return res.status(404).json({ error: "Quiz not found" });
  const score = quiz.questions.reduce((total, question, index) => total + (input.answers[index] === question.answer ? 1 : 0), 0);
  const percentage = Math.round((score / quiz.questions.length) * 100);
  store.progress.quizAttempts += 1;
  store.progress.averageScore = Math.round(((store.progress.averageScore * (store.progress.quizAttempts - 1)) + percentage) / store.progress.quizAttempts);
  store.activities.unshift({ id: randomUUID(), title: `Completed ${quiz.title}`, detail: `${percentage}% score`, time: "Just now", type: "quiz" });
  await saveStore(store);
  return res.json({ quizId: quiz.id, score, total: quiz.questions.length, percentage, feedback: percentage >= 80 ? "Excellent work. You are ready to apply this concept." : percentage >= 60 ? "Good foundation. Review the explanations and try again." : "Keep going. Revisit the cited material and retake the quiz." });
});

router.get("/progress", async (_req, res) => {
  const store = await getStore();
  res.json(store.progress);
});

router.get("/memory", async (_req, res) => {
  const store = await getStore();
  res.json(store.memory);
});

router.post("/memory", async (req, res) => {
  const input = CreateMemoryBody.parse(req.body);
  const store = await getStore();
  const item: MemoryItem = { id: randomUUID(), category: input.category, content: input.content, source: "Learner preference", createdAt: now() };
  store.memory.unshift(item);
  store.activities.unshift({ id: randomUUID(), title: "Updated learner memory", detail: item.content, time: "Just now", type: "memory" });
  await saveStore(store);
  res.status(201).json(item);
});

router.get("/report", async (_req, res) => {
  const store = await getStore();
  res.json({
    title: "AI Learning & Study Assistant",
    problemStatement: "Students often study from scattered notes without a consistent plan, grounded explanations, or feedback about what to review next.",
    description: "An agentic AI learning workspace that turns course materials into a personalized, evidence-aware study loop.",
    objectives: ["Create personalized learning plans", "Answer questions from course materials using RAG", "Remember student preferences and progress", "Generate quizzes through tool calling", "Track measurable learning outcomes"],
    solution: ["The Agent orchestrates retrieval, memory, generation, and scoring tools.", "RAG retrieves the most relevant indexed passages before an answer is written.", "Memory stores learning style, goals, and progress signals so plans and explanations adapt.", "Tool calling makes retrieval, learner-context lookup, and quiz scoring explicit, inspectable steps."],
    technologies: ["React + Vite", "Node.js + Express", "PostgreSQL + Drizzle ORM", "OpenAPI + generated React Query hooks", "OpenAI Chat Completions", "App Storage with presigned uploads"],
    workflow: ["Upload and index course material", "Retrieve relevant chunks for the learner's question", "Read learner memory and active plan progress", "Generate a grounded answer, plan, or quiz", "Score activity and persist progress for the next session"],
    results: [`${store.documents.length} course material(s) indexed`, `${store.progress.questionsAnswered} grounded questions answered`, `${store.progress.quizAttempts} quiz attempt(s) recorded`, `${store.progress.averageScore}% average quiz score`, `${store.memory.length} learner memory item(s) guiding personalization`],
    conclusion: "The project demonstrates a complete Agent + RAG + Memory + Tool Calling loop in a student-facing product, with visible evidence instead of a disconnected chatbot.",
    challenges: ["Balancing concise answers with citations", "Keeping generated quiz content grounded in source material", "Designing a useful memory model without overwhelming the learner", "Handling incomplete or unsupported uploads gracefully"],
    futureScope: ["Semantic embeddings and vector search for larger libraries", "Spaced-repetition scheduling based on recall history", "Multimodal PDF and diagram understanding", "Instructor dashboards and collaborative course spaces", "Voice-based tutoring and accessibility modes"],
    references: ["IBM watsonx.ai Agentic AI concepts", "OpenAI Chat Completions and function calling documentation", "Retrieval-Augmented Generation research literature", "Drizzle ORM and PostgreSQL documentation"],
  });
});

export default router;